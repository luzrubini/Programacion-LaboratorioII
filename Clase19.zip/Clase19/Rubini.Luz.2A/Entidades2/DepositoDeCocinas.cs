﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Entidades2
{
    public class DepositoDeCocinas
    {
        private int _capacidadMaxima;
        private List<Cocina> _lista;
        #region Constructores
        private DepositoDeCocinas()
        {
            this._lista = new List<Cocina>();
        }
        public DepositoDeCocinas(int capacidad) : this()
        {
            this._capacidadMaxima = capacidad;
        }
        #endregion
        #region Metodos
        private int GetIndice(Cocina c)
        {
            int indice = -1;
            foreach (Cocina item in this._lista)
            {
                if (c == item)
                {
                    indice = this._lista.IndexOf(item);
                    break;
                }
            }
            return indice;
        }
        public bool Agregar(Cocina c)
        {
            return (this + c);
        }
        public bool Remover(Cocina c)
        {
            return (this - c);
        }
        //Guarda el contenido del ToString del deposito de cocina + los detalles (cod-etc)
        //Lo guarto en un archivo, devuelve true si lo logro y false si no.
        public bool Guardar(string cadena) 
        {
            bool retorno = false;
            try
            {
                using (StreamWriter sw = new StreamWriter(cadena)) //true: hay arch y agrega informacion, false lo pisa.
                {
                    sw.Write(this.ToString());
                    retorno = true;
                }
            }
            catch (Exception e)
            {
                Console.Write(e.Message);
            }
            return retorno;
        }
        public bool Recuperar(string cadena)
        {
            bool retorno = false;
            try
            {
                StreamReader sr = new StreamReader(cadena);
                Console.Write(sr.ReadToEnd());
                retorno = true;
                sr.Close();
            }
            catch (Exception e)
            {
                Console.Write(e.Message);
            }
            return retorno;
        }
        #endregion
        #region Sobrecargas
        public static bool operator +(DepositoDeCocinas d, Cocina c)
        {
            bool retorno = false;
            if (d._lista.Count < d._capacidadMaxima)
            {
                d._lista.Add(c);
                retorno = true;

            }

            return retorno;
        }
        public static bool operator -(DepositoDeCocinas d, Cocina c)
        {
            bool retorno = false;
            int indice = d.GetIndice(c);
            if (indice != -1)
            {
                d._lista.RemoveAt(indice);
                retorno = true;
            }
            return retorno;
        }
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Capacidad maxima: {0}\r\n", this._capacidadMaxima);
            sb.AppendLine("Listado de Cocinas ");
            foreach (Cocina c in this._lista)
            {
                sb.AppendFormat("{0}\r\n", c.ToString());
            }
            return sb.ToString();
        }
        #endregion
    }
}
