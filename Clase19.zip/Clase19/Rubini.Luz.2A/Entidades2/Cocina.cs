﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades2
{
    public class Cocina
    {
        private int _codigo;
        private bool _esIndustrial;
        private double _precio;
        #region Constructores
        public Cocina(int codigo, double precio, bool esIndustrial)
        {
            this._codigo = codigo;
            this._precio = precio;
            this._esIndustrial = esIndustrial;
        }
        #endregion
        #region Propiedades
        public int Codigo
        {
            get
            {
                return this._codigo;
            }
        }
        public double Precio
        {
            get
            {
                return this._precio;
            }
        }
        public bool EsIndustrial
        {
            get
            {
                return this._esIndustrial;
            }
        }
        #endregion
        #region Metodos
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Codigo: {0} -- Precio: {1} -- Es industrial? {2}", this.Codigo, this.Precio, this.EsIndustrial);
            return sb.ToString();
        }

        #endregion
        #region Sobrecargas
        public static bool operator ==(Cocina c1, Cocina c2)
        {
            return (c1._codigo == c2._codigo);
        }
        public static bool operator !=(Cocina c1, Cocina c2)
        {
            return !(c1 == c2);

        }
        #endregion
    }
}
