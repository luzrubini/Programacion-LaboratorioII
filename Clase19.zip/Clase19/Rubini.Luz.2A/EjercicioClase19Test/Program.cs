﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Clase19;


namespace EjercicioClase19Test
{
    class Program
    {
        static void Main(string[] args)
        {
            Persona p1 = new Persona("Lucas", "Duarte", 20, ESexo.Masculino);
            Persona p2 = new Persona("Deniss", "Vasiljevs", 19, ESexo.Masculino);
            Console.WriteLine(p1.ObtenerDatos());
            PersonaExternaHeredada pe1 = new PersonaExternaHeredada("Rocio", "Zarate", 20, Entidades.Externa.ESexo.Femenino);
            Console.WriteLine(pe1.ObtenerDatos());
            Entidades.Externa.Sellada.PersonaExternaSellada pes1 = new Entidades.Externa.Sellada.PersonaExternaSellada("Jazmin", "Perez", 21, Entidades.Externa.Sellada.ESexo.Femenino);
            Console.WriteLine(pes1.ObtenerDatos());
            Console.WriteLine(pes1.EsNulo());
            Int32 numero = 45348;
            Int32 numero2 = 36985;
            Int32 numero3 = 453;
            Console.WriteLine(numero.CantidadDigitos());
            Console.WriteLine(numero.TieneLaMismaCantidad(numero2));
            Console.WriteLine(numero.TieneLaMismaCantidad(numero3));
            foreach (Persona item in p1.TraerBD())
            {
                Console.WriteLine(item.ObtenerDatos());
            }
            p2.BorrarBD(22);
            Console.ReadKey();

        }
    }
}
