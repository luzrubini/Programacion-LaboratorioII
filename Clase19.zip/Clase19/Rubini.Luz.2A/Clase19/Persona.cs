﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase19
{
    public class Persona
    {
        private string _nombre;
        private string _apellido;
        private int _edad;
        private ESexo _sexo;
        #region Constructores
        public Persona(string n, string a, int e, ESexo s)
        {
            this._nombre = n;
            this._apellido = a;
            this._edad = e;
            this._sexo = s;
        }
        #endregion
        #region Propiedades
        protected string Nombre { get { return this._nombre; } }
        protected string Apellido { get { return this._apellido; } }
        protected int Edad { get { return this._edad; } }
        protected ESexo Sexo { get { return this._sexo; } }
        #endregion
        #region Metodos Getters
        public string GetNombre()
        {
            return this.Nombre;
        }
        public string GetApellido()
        {
            return this.Apellido;
        }
        public string GetEdad()
        {
            return this.Edad.ToString();
        }
        public ESexo GetSexo()
        {
            return this.Sexo;
        }
        #endregion
        #region Metodos

        public string ObtenerDatos()
        {
            return this.GetNombre() + "-" + this.GetApellido() + "-" + this.GetEdad() + "-" + this.GetSexo();
        }
        #endregion

    }
}
