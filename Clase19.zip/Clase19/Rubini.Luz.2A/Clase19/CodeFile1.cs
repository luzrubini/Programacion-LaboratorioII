﻿public enum ESexo
{
    Femenino, 
    Masculino,
    Indeterminado
}