﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EjercicioClase18
{
    public partial class FrmPrincipal : Form
    {
        public FrmPrincipal()
        {
            InitializeComponent();
        }

        public void MiManejadorClick(object obj, EventArgs e)
        {
            MessageBox.Show(((Control)obj).Name);
        }
        public void MiOtroManejadorClick(object obj, EventArgs e)
        {
            this.button2.Click -= new EventHandler(MiManejadorClick);
            this.button1.Click += new EventHandler(MiManejadorClick);
        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {
            /*this.button1.Click += new EventHandler(MiManejadorClick);
            this.button2.Click += new EventHandler(MiManejadorClick);
            this.Click += new EventHandler(MiOtroManejadorClick);
            this.textBox1.Click += new EventHandler(MiManejadorClick);
            this.button1.Click += new EventHandler(CambiarFondo);*/
            this.button1.Click += new EventHandler(MiManejadorClick);
            this.button1.Click += new EventHandler(ManejadorCentral);
        }
        public void CambiarFondo(object obj, EventArgs e)
        {
            ((Control)obj).BackColor = Color.CornflowerBlue;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.button1.Click -= new EventHandler(MiManejadorClick);
            this.button1.Click -= new EventHandler(CambiarFondo);
            this.button2.Click -= new EventHandler(MiManejadorClick);
            this.button2.Click -= new EventHandler(MiOtroManejadorClick);
            this.Click -= new EventHandler(MiOtroManejadorClick);
            this.textBox1.Click -= new EventHandler(MiManejadorClick);
        }
        public void ManejadorCentral(object obj, EventArgs e)
        {
            if (obj.Equals(this.button1))
            {
                this.button1.Click -= new EventHandler(MiManejadorClick);
                this.button1.Click -= new EventHandler(ManejadorCentral);
                this.button2.Click += new EventHandler(MiManejadorClick);
                this.button2.Click += new EventHandler(ManejadorCentral);
            }
            if (obj.Equals(this.button2))
            {
                this.button2.Click -= new EventHandler(MiManejadorClick);
                this.button2.Click -= new EventHandler(ManejadorCentral);
                this.textBox1.Click += new EventHandler(MiManejadorClick);
                this.textBox1.Click += new EventHandler(ManejadorCentral);
            }
            if (obj.Equals(this.textBox1))
            {
                this.textBox1.Click -= new EventHandler(MiManejadorClick);
                this.textBox1.Click -= new EventHandler(ManejadorCentral);
                this.button1.Click += new EventHandler(MiManejadorClick);
                this.button1.Click += new EventHandler(ManejadorCentral);
            }
        }
    }
}
