﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Xml;
using System.Data;
using System.Xml.Serialization;

namespace EjercicioClase16
{
    class Program
    {
        static void Main(string[] args)
        {
            SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);

            SqlCommand comando = new SqlCommand();
            
            comando.CommandText = "SELECT * FROM Televisores";
            comando.CommandType = System.Data.CommandType.Text;
            comando.Connection = conexion;
            conexion.Open();
            SqlDataReader lector = comando.ExecuteReader();
            List <Televisores> listaTelevisor = new List<Televisores>();
            while (lector.Read())
            {
                Console.WriteLine(lector[0] + "--" + lector[1] + "--" + lector[2] + "--" + lector[3] + "--" + lector[4]);
                Televisores t = new Televisores(lector.GetInt32(0), lector.GetString(1), lector.GetDouble(2), lector.GetInt32(3), lector.GetString(4)); 
                listaTelevisor.Add(t);
            }
            conexion.Close();
            XmlSerializer sr = new XmlSerializer(typeof(List<Televisores>));
            XmlTextWriter wr = new XmlTextWriter(@"Televisores.Xml",Encoding.UTF8);
            XmlTextReader rd = new XmlTextReader("Televisores.Xml");
            sr.Serialize(wr, listaTelevisor);
            wr.Close(); // lo cerramos para que no pinche

            List<Televisores> listaTelevisorRead;
            listaTelevisorRead = (List<Televisores>)sr.Deserialize(rd);
            rd.Close();

            conexion.Open();

            lector = comando.ExecuteReader(); //genero replica 

            DataTable dataTable = new DataTable("Televisor"); //representacion en memoria de una tabal en base de datos

            dataTable.Load(lector); //ya lo agrega al data table

            conexion.Close(); //volvemos a cerrar

            dataTable.WriteXmlSchema("Televisores_esquema.xml"); //guardamos el esquema
            dataTable.WriteXml("Televisore_dt.xml"); //leemos el esquema

            DataTable dataTable2 = new DataTable();

            dataTable2.ReadXmlSchema("Televisores_esquema.xml");//primero leemos el esquema
            dataTable2.ReadXml("Televisore_dt.xml");

            Televisores telenueva = new Televisores(5, "sony", 22000, 45, "Estados Unidos");
            Televisores telenueva2 = new Televisores(5, "LG", 5600, 45, "Canada");

            //Console.WriteLine(telenueva.Insertar());
            Console.WriteLine(Televisores.Borrar(telenueva2));


            Console.ReadKey();

        }
    }
}
