﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntidadesClase17;

namespace EjercicoClase17
{
    class Program
    {
        static void Main(string[] args)
        {
            Televisores t = new Televisores(127, "Samsung", 35900, 60, "Argentina");
            t.MiEvento += new MiDelegado(PruebaEvento);
            t.MiEvento += new MiDelegado(new Program().PruebaEvento2);
            t.EventoTV += new DelegadoTV(new Program().Mostrar);
            t.Insertar();
            //Televisores.Borrar(t);
            Console.ReadKey();
            
        }
        public static void PruebaEvento()
        {
            Console.WriteLine("Se inserto un registro en la base de datos");
        }
        public void PruebaEvento2()
        {
            Console.WriteLine("Estoy en el segundo de los métodos del delegado.");
        }
        public void Mostrar(Televisores t,TVEventsArgs te)
        {
            Console.WriteLine("{0}--{1}--{2}--{3}--{4}",t.codigo,t.marca,t.precio,t.pulgadas,t.pais);
            Console.WriteLine(te.Fecha);
        }
    }
}
