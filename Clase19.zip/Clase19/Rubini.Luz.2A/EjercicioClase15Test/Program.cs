﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EjercicioClase15;

namespace EjercicioClase15Test
{
    class Program
    {
        static void Main(string[] args)
        {
            string mostrar = "";
            int control = 0;
            Console.WriteLine("Guardar en:\n 1)Escritorio\n 2)Repositorio actual.\n 3)Mis Imagenes");
            int.TryParse(Console.ReadLine(), out control);
            switch (control)
            {
                case 1:
                    AdministradorArchivos.Escribir(Environment.GetFolderPath(Environment.SpecialFolder.Desktop)+"\\texto.txt", "Hola...");
                    AdministradorArchivos.Leer(Environment.GetFolderPath(Environment.SpecialFolder.Desktop)+"\\texto.txt", out mostrar);
                    break;
                case 2:
                    AdministradorArchivos.Escribir(AppDomain.CurrentDomain.BaseDirectory + "\\texto.txt", "Hola!!");
                    AdministradorArchivos.Leer(AppDomain.CurrentDomain.BaseDirectory + "\\texto.txt", out mostrar);
                    break;
                case 3:
                    AdministradorArchivos.Escribir(Environment.GetFolderPath(Environment.SpecialFolder.MyPictures) + "\\texto.txt", "Hola!.");
                    AdministradorArchivos.Leer(Environment.GetFolderPath(Environment.SpecialFolder.MyPictures) + "\\texto.txt", out mostrar);
                    break;
                default:
                    break;
            }
            Console.WriteLine(mostrar);
            Console.ReadLine();
        }
    }
}
