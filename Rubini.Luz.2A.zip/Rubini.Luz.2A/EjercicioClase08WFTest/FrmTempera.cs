﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EjercicioClase07Entidades;


namespace EjercicioClase08WFTest
{
    public partial class FrmTempera : Form
    {
        private Tempera _miTempera;
        public Tempera MiTempera { get { return _miTempera; } }
        public FrmTempera()
        {
            InitializeComponent();
            foreach (ConsoleColor color in Enum.GetValues(typeof(ConsoleColor)))
            {
                this.cmbColor.Items.Add(color);
            }
            this.cmbColor.SelectedItem = ConsoleColor.DarkRed;
            this.cmbColor.DropDownStyle = ComboBoxStyle.DropDownList;
        }
        public FrmTempera(Tempera tempera): this()
        {
            
        }
       
        private void btnAceptar_Click(object sender, EventArgs e)
        {
            this._miTempera = new Tempera(sbyte.Parse(this.txtCantidad.Text), (ConsoleColor)this.cmbColor.SelectedItem, this.txtMarca.Text);
            this.DialogResult = DialogResult.OK;
        }
    }
}
