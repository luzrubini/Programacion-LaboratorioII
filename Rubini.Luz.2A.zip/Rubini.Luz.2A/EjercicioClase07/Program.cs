﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EjercicioClase07Entidades;


namespace EjercicioClase07
{
    class Program
    {
        static void Main(string[] args)
        {
            Tempera t1 = new Tempera(2, ConsoleColor.Cyan, "Bic");
            Console.WriteLine(t1);
            Paleta p1 = 2;
            Console.WriteLine((string)p1);
            Console.ReadKey();
        }
    }
}
