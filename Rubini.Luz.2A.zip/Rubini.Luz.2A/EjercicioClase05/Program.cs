﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase05
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercico Clase 05/06";
            
            Tinta tinta1 = new Tinta(ConsoleColor.DarkCyan, ETipoTinta.Comun);
            Tinta tinta2 = new Tinta(ConsoleColor.DarkMagenta);
            Tinta tinta3 = new Tinta(ConsoleColor.DarkCyan, ETipoTinta.Comun);

            //Muestro las tres tintas 
            Console.WriteLine("Tinta 1: {0}", Tinta.Mostrar(tinta1));
            Console.WriteLine("Tinta 2: {0}", Tinta.Mostrar(tinta2));
            Console.WriteLine("Tinta 3: {0}", Tinta.Mostrar(tinta3));

            //Comparo las tintas entre sí:
            Console.WriteLine("t1==t2? {0}", tinta1 == tinta2);
            Console.WriteLine("t2==t3? {0}", tinta2 == tinta3);
            Console.WriteLine("t1==t3? {0}", tinta1 == tinta3);

            //Declaro dos plumas:
            Pluma pluma1 = new Pluma("Filgo", 2, tinta1);
            Pluma pluma2 = new Pluma("Bic", 96, tinta2);
            Pluma pluma3 = new Pluma("Parker",10);

            //Muestro las plumas
            Console.WriteLine("Pluma 1: " + pluma1);
            Console.WriteLine("Pluma 2: " + pluma2);
            Console.WriteLine("Pluma 3: " + pluma3);

            //Comparo
            Console.WriteLine("p1==t2? {0}", pluma1 == tinta2);
            Console.WriteLine("p1==t1? {0}", pluma1 == tinta1);

            //Sumo
            Console.WriteLine("Sumo tinta: ");
            Console.WriteLine("p1+t1----->" + (pluma1 + tinta1));
            Console.WriteLine("p2+t2----->" + (pluma2 + tinta2));
            Console.WriteLine("p1+t2----->" + (pluma1 + tinta2));

            //Resta
            Console.WriteLine("Resto tinta: ");
            Console.WriteLine("p1-t1----->" + (pluma1 - tinta1));
            Console.WriteLine("p2-t2----->" + (pluma2 - tinta2));
            Console.WriteLine("p1-t2----->" + (pluma1 - tinta2));
            
            

            Console.ReadKey();
        }
    }
}
