﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;

namespace EjercicioClase02
{
    class Program
    {
        static void Main(string[] args)
        {
            Sello.mensaje = "Hola";
            Console.WriteLine("Mensaje: {0}", Sello.Imprimir());
            Console.WriteLine("Mensaje en color: ");
            Sello.color = ConsoleColor.Magenta;
            Sello.ImprimirEnColor();
            Sello.Borrar();
            Console.WriteLine("Mensaje borrado: ");
            Console.WriteLine(Sello.Imprimir());
            Console.ReadKey();
        }
    }
}
