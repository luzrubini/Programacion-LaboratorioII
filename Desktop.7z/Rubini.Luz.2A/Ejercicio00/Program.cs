﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio00
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercico 00";
            string nombre;
            int edad;

            Console.WriteLine("Ingrese su nombre y edad ");
            nombre = Console.ReadLine();
            int.TryParse(Console.ReadLine(),out edad);
            Console.WriteLine("Nombre: {0} -- {1}", nombre, edad);
            Console.ReadKey();
        }
    }
}
