using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PracticaParcial2;

namespace PracticaParcial2Test
{
  class Program
  {
    static void Main(string[] args)
    {
      Vehiculo v1 = new Vehiculo("LNR485", 2, EMarca.Iveco);
      Vehiculo v2 = new Vehiculo("FDG458", 4, EMarca.Fiat);

      Auto a1 = new Auto("CDD147", EMarca.Ford, 3);
      Moto m1 = new Moto("VFD454",EMarca.Zanella,2,25);
      Camion c1 = new Camion(v1, 14);

      Console.WriteLine(v1.ToString());
      Console.WriteLine(a1.ToString());
      Console.WriteLine(m1.ToString());
      Console.WriteLine(c1.ToString());
      Console.ReadLine();
    }
  }
}
