using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticaParcial2
{
    public class Vehiculo
    {
        protected string _patente;
        protected byte _cantRuedas;
        protected EMarca _marca;
    #region Propiedades
    public string MiPatente
    {
      get
      {
        return this._patente;
      }
    }
    public byte Ruedas
    { get
      {
         return this._cantRuedas;
      }
      set
      {
        this._cantRuedas = value; 
      }
    }
    public EMarca Marca
    {
      get
      {
        return this._marca;
      }
    }
    #endregion
    #region Constructores
    public Vehiculo(string patente, byte ruedas, EMarca marca)
        {
          this._patente = patente;
          this._cantRuedas = ruedas;
          this._marca = marca;
        }
    #endregion
    #region Metodos
    protected virtual string Mostrar()
    {
      StringBuilder stringBuild = new StringBuilder();
      stringBuild.AppendLine("-----------------------");
      stringBuild.AppendFormat("Patente: {0} \nCantidad de ruedas: {1} \nMarca: {2}", this._patente, this._cantRuedas, this._marca);
      return stringBuild.ToString();
    }
    public override string ToString()
    {
      return this.Mostrar();
    }
    #endregion
    #region Sobrecargas
    public static bool operator ==(Vehiculo v1, Vehiculo v2)
    {
      return (v1._patente == v2._patente && v1._marca == v2._marca);
    }
    public static bool operator !=(Vehiculo v1, Vehiculo v2)
    {
      return !(v1 == v2);
    }
    #endregion
  }
}
