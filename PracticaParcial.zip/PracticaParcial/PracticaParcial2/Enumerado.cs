public enum EMarca
{
  Honda,
  Ford,
  Zanella,
  Scania,
  Iveco,
  Fiat,
}
public enum EVehiculo
{
  Auto,
  Moto,
  Camion
}
