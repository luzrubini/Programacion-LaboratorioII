using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticaParcial2
{
  public class Camion : Vehiculo
  {
    protected float _tara;
    #region Constructores
    public Camion(string patente, byte rueda, EMarca marca, int tara) :base (patente,rueda,marca)
    {
      this._tara = tara;
    }
    public Camion(Vehiculo vehiculo, int tara) : this(vehiculo.MiPatente, vehiculo.Ruedas, vehiculo.Marca, tara)
    {
      
    }
    #endregion
    #region Sobrecargas
    protected override string Mostrar()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendLine(base.Mostrar());
      sb.AppendFormat("Cantidad de asientos: {0}", this._tara);
      return sb.ToString();
    }
    public override string ToString()
    {
      return base.ToString();
    }
    #endregion
  }
}
