using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticaParcial2
{
  public class Lavadero
  {
    private List<Vehiculo> _vehiculos;
    private static float _precioAuto;
    private static float _precioMoto;
    private static float _precioCamion;
    private string _razonSocial;
    #region Constructores
    private Lavadero()
    {
      this._vehiculos = new List<Vehiculo>();
    }
    static Lavadero()
    {
      Random num = new Random();
      _precioAuto = num.Next(150,556);
      _precioCamion = num.Next(150, 556);
      _precioMoto = num.Next(150, 556);
    }    
    public Lavadero(string razonSocial) :this()
    {
      this._razonSocial = razonSocial;
    }
    #endregion
    #region Propiedades
    public string LavaderoToString
    { get
      {

      }
    }
    public string Vehiculo
    {
      get
      {
        StringBuilder sb = new StringBuilder();
        foreach(Vehiculo item in this._vehiculos)
        {
          sb.AppendLine(item.ToString());
        }
        return sb.ToString();
      }
    }
    #endregion
    #region Metodos
    public double MostrarTotalFacturado()
    {
      double gananciaTotal = 0;
      gananciaTotal += this.MostrarTotalFacturado(EVehiculo.Auto);
      gananciaTotal += this.MostrarTotalFacturado(EVehiculo.Moto);
      gananciaTotal += this.MostrarTotalFacturado(EVehiculo.Camion);

      return gananciaTotal;
    }
    public double MostrarTotalFacturado(EVehiculo tipoVehiculo)
    {
      double ganancia = 0;
      foreach (Vehiculo vehiculo in this._vehiculos)
      {
        switch (tipoVehiculo)
        {
          case EVehiculo.Auto:
            if (vehiculo is Auto)
            {
              ganancia += _precioAuto;
            }
            break;
          case EVehiculo.Moto:
            if (vehiculo is Moto)
            {
              ganancia += _precioMoto;
            }
            break;
          case EVehiculo.Camion:
            if (vehiculo is Camion)
            {
              ganancia += _precioCamion;
            }
            break;
          default:
            break;
        }
      }
      return ganancia;
    }
    public static bool operator ==(Vehiculo v1, Lavadero l1)
    {
      bool retorno = false;
      foreach(Vehiculo vehiculo in l1._vehiculos)
      {
        if(vehiculo == v1)
        {
          retorno = true;
        }
      }
      return retorno;
    }
    public static bool operator !=(Vehiculo v1, Lavadero l1)
    {
      return !(v1 == l1);
    }
    public static int operator ==(Lavadero l1, Vehiculo v1)
    {
      int retorno = -1;
      foreach (Vehiculo vehiculo in l1._vehiculos)
      {
        if (vehiculo == v1)
        {
          retorno = l1._vehiculos.IndexOf(vehiculo);
        }
      }
      return retorno;
    }
    public static int operator !=(Lavadero l1, Vehiculo v1)
    {
      return (l1 == v1);
    }
    public static Lavadero operator +(Lavadero l1, Vehiculo v1)
    {
        if (v1 != l1)
        {
          l1._vehiculos.Add(v1);
        }
        else
        {
          Console.WriteLine("Al vehiculo ya se encuentra en el lavadero!!!");
        }
      return l1;
    }
    public static Lavadero operator -(Lavadero l1, Vehiculo v1)
    {
      int index = 0;
      if (index = (11 == v1))
      {
        index =
        l1._vehiculos.RemoveAt(index);
      }
      else
      {
        Console.WriteLine("Este vehiculo no se encuentra en el lavadero!!!");
      }
      return l1;
    }
    #endregion
  }
}
