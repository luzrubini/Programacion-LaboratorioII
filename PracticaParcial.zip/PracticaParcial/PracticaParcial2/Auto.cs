using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticaParcial2
{
  public class Auto : Vehiculo
  {
    protected int _cantDeAsientos;

    #region Constructores
    public Auto(string patente, byte ruedas, EMarca marca, int asientos) :base(patente, ruedas, marca)
    {
      this._cantDeAsientos = asientos;
    }
    public Auto(string patente, EMarca marca, int asientos) :this(patente, 4, marca, asientos)
    {
      
    }
    #endregion
    #region Sobrecargas
    protected override string Mostrar()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendLine(base.Mostrar());
      sb.AppendFormat("Cantidad de asientos: {0}", this._cantDeAsientos);
      return sb.ToString();
    }
    public override string ToString()
    {
      return base.ToString();
    }
    #endregion

  }
}
