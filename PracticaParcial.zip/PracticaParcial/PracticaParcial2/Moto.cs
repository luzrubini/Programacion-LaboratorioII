using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticaParcial2
{
  public class Moto : Vehiculo
  {
    protected float _cilindrada;
    #region Constructores
    public Moto(string patente, EMarca marca, byte ruedas, float cilindrada) : this(marca,cilindrada,ruedas,patente)
    {
      
    }
    public Moto(EMarca marca, float cilindrada, byte ruedas, string patente) :base(patente,ruedas,marca)
    {
      this._cilindrada = cilindrada;
    }
    #endregion
    #region Sobrecargas
    protected override string Mostrar()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendLine(base.Mostrar());
      sb.AppendFormat("Cantidad de asientos: {0}", this._cilindrada);
      return sb.ToString();
    }
    public override string ToString()
    {
      return base.ToString();
    }
    #endregion
  }
}
