﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EjercicioClase04Entidades;

namespace EjercicioClase04
{
    class Program
    {
        static void Main(string[] args)
        {
            Cosa cosa1 = new Cosa("hola");
            Console.WriteLine(Cosa.Mostrar(cosa1));
            cosa1.cadena = "Luz Rubini";
            cosa1.numero = 7845645454;
            cosa1.fecha = DateTime.Now;
            Console.WriteLine(Cosa.Mostrar(cosa1));
            Console.ReadKey();
        }
    }
}
