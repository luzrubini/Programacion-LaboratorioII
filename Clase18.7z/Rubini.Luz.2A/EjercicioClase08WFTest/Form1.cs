﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EjercicioClase07Entidades;

namespace EjercicioClase08WFTest
{
    public partial class Form1 : Form
    {
        PaletaColeccion _miPaleta;
        public Form1()
        {
            InitializeComponent();
            this._miPaleta = 5;
            this.grbPaleta.Text = "Paleta de colores";
            this.txtTexto.Multiline = true;
            this.btnMas.Text = "+";
            this.btnMenos.Text = "-";
        }

        private void agregarPaletaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.grbPaleta.Visible = true;
            this.agregarPaletaToolStripMenuItem.Enabled = false;
        }

        private void btnMas_Click(object sender, EventArgs e)
        {
            FrmTempera form = new FrmTempera();
            DialogResult rta = form.ShowDialog();
            if (rta == DialogResult.OK)
            {
                this._miPaleta += form.MiTempera;
                this.txtTexto.Text = (string)this._miPaleta;
            }
        }
        private void btnMenos_Click(object sender, EventArgs e)
        {
            string texto = this.txtTexto.SelectedText;
            int index = 0;
            foreach(string item in this.txtTexto.Lines)
            {
                if(texto == item)
                {
                    break;
                }
                index ++;
            }
            
            texto += "  " + index.ToString();
            MessageBox.Show(texto);

            FrmTempera form = new FrmTempera();

            
            
        }
    }
}
