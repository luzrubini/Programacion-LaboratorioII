﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Xml;
using System.Data;
using System.Xml.Serialization;
namespace EjercicioClase16
{
    public class Televisores
    {
        public int codigo;
        public string marca;
        public double precio;
        public int pulgadas;
        public string pais;

        public Televisores(int codigo, string marca, double precio, int pulgadas, string pais)
        {
            this.codigo = codigo;
            this.marca = marca;
            this.precio = precio;
            this.pulgadas = pulgadas;
            this.pais = pais;
        }
        public Televisores()
        {
        }
        public bool Insertar()
        {
            bool retorno = false;

            SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);
            SqlCommand comando = new SqlCommand();


            comando.CommandText = string.Format("INSERT INTO Televisores values ({0},'{1}',{2},{3},'{4}')", this.codigo, this.marca, this.precio, this.pulgadas, this.pais);
            comando.CommandType = System.Data.CommandType.Text;
            comando.Connection = conexion;
            try
            {
                conexion.Open();
                comando.ExecuteNonQuery(); //ejecuta consultas que no van a retornar ningun tipo de resultado
                conexion.Close();
                retorno = true;
            }
            catch (Exception e)
            {
                throw e;
            }


            return retorno;
        }
        public static bool Modificar(Televisores t)
        {
            bool retorno = false;
            SqlConnection connection = new SqlConnection(Properties.Settings.Default.Conexion);
            SqlCommand command = new SqlCommand();
            command.CommandText = string.Format("UPDATE Televisores SET marca = '{0}', precio = {1}, pulgadas = {2}, pais = '{3}' WHERE codigo = {4}", t.marca, t.precio, t.pulgadas, t.pais, t.codigo);
            command.CommandType = System.Data.CommandType.Text;
            command.Connection = connection;
            try
            {
                connection.Open();
                command.ExecuteNonQuery(); //ejecuta consultas que no van a retornar ningun tipo de resultado
                connection.Close();
                retorno = true;
            }
            catch (Exception e)
            {
                throw e;
            }

            return retorno;
        }
        public static bool Borrar(Televisores t)
        {
            bool retorno = true;
            SqlConnection connection = new SqlConnection(Properties.Settings.Default.Conexion);
            SqlCommand command = new SqlCommand();
            command.CommandText = string.Format("DELETE Televisores WHERE codigo = {0}", t.codigo);
            command.CommandType = System.Data.CommandType.Text;
            command.Connection = connection;
            try
            {
                connection.Open();
                command.ExecuteNonQuery(); //ejecuta consultas que no van a retornar ningun tipo de resultado
                connection.Close();
                retorno = true;
            }
            catch (Exception e)
            {
                throw e;
            }
            return retorno;
        }
        public static List<Televisores> TraerTodos()
        {
            SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);

            SqlCommand comando = new SqlCommand();

            comando.CommandText = "SELECT * FROM Televisores";
            comando.CommandType = System.Data.CommandType.Text;
            comando.Connection = conexion;
            conexion.Open();
            SqlDataReader lector = comando.ExecuteReader();
            List<Televisores> listaTelevisor2 = new List<Televisores>();
            while (lector.Read())
            {
                 Televisores t = new Televisores(lector.GetInt32(0), lector.GetString(1), lector.GetDouble(2), lector.GetInt32(3), lector.GetString(4));
                 listaTelevisor2.Add(t);
            }
            conexion.Close();
            return listaTelevisor2;
        }
        public static Televisores TraerUno(int num)
        {
            SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);

            SqlCommand comando = new SqlCommand();

            comando.CommandText = "SELECT * FROM Televisores WHERE codigo = "+num+"";
            comando.CommandType = System.Data.CommandType.Text;
            comando.Connection = conexion;
            conexion.Open();
            SqlDataReader lector = comando.ExecuteReader();
            lector.Read();
            Televisores televisor = new Televisores(lector.GetInt32(0), lector.GetString(1), lector.GetDouble(2), lector.GetInt32(3), lector.GetString(4));
            conexion.Close();
            return televisor;
        }
    }
}
