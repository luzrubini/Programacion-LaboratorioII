﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio02
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercico 02";
            int num = 0;
            double cubo = 0;
            double cuadrado = 0;

            Console.WriteLine("Ingresar numero: ");
            int.TryParse(Console.ReadLine(), out num);

            while (num < 0)
            {
                Console.WriteLine("ERROR ¡Reingresar numero!");
                int.TryParse(Console.ReadLine(), out num);
            }

            cubo = Math.Pow(num, 3);
            cuadrado = Math.Pow(num, 2);

            Console.WriteLine("Cuadrado: {0} \nCubo: {1}", cuadrado, cubo);
            Console.ReadKey();
        }
    }
}
