﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;

namespace EjercicioClase02
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercico Clase 02/03";

            Sello.mensaje = "Hola";
            Console.WriteLine("Mensaje: \n{0}", Sello.Imprimir());
            Console.WriteLine("Mensaje en color: ");
            Sello.color = ConsoleColor.DarkGreen;
            Sello.ImprimirEnColor();
            Sello.Borrar();
            Console.WriteLine("Mensaje borrado: ");
            Console.WriteLine(Sello.Imprimir());
            Console.ReadKey();
        }
    }
}
