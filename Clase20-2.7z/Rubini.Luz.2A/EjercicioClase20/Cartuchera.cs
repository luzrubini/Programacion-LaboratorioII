﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase20
{
    public class Cartuchera<T>
    {
        //*-marca : string
        //*-capacidad : byte
        protected string _marca;
        protected byte _capacidad;
        protected List<T> _elementos;
        //*-elementos : list<T>

        //constructor privado
        private Cartuchera()
        {
            this._elementos = new List<T>();
        }
        //Cartuchera(byte)
        public Cartuchera(byte capacidad):this()
        {
            this._capacidad = capacidad;
        }
        //sobrecarga implicit
        //implicit (byte) : Cartuchera
        //Add : void -> agrega un elemento a la cartuchera
        public void Add(Cartuchera<T> d, T a)
        {
            if (d._elementos.Count < d._capacidad)
            {
                d._elementos.Add(a);
            }
        }
        //Remove(T) : bool -> quita un elemento de la cartuchera
        public bool Remove(Cartuchera<T> d, T a)
        {
            bool retorno = false;
            int indice = -1;
            foreach (T item in d._elementos)
            {
                if (a.Equals(item))
                {
                    indice = d._elementos.IndexOf(item);
                    break;
                }
            }
            if (indice != -1)
            {
                d._elementos.RemoveAt(indice);
                retorno = true;
            }
            return retorno;
        }
        //ToString : string -> retorna estados completos de la instancia
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Capacidad maxima: {0}\n", this._capacidad);
            sb.AppendLine("Listado: ");
            foreach (T a in this._elementos)
            {
                sb.AppendFormat("{0}\n", a.ToString());
            }
            return sb.ToString();
        }
    }
}
