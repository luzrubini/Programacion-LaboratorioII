﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase20
{
    public abstract class Utiles
    {
        //utiles(abstract)
        //*-precio : double
        //*-marca : string
        protected double _precio;
        protected string _marca;

        public Utiles(double precio, string marca)
        {
            this._precio = precio;
            this._marca = marca;
        }

        //*-Precio(get; set) - abstract
        //*-Marca(get; set) - abstract

        public abstract double Precio
        {
            get; set;
        }
        public abstract string Marca
        {
            get; set;
        }

        //utilesToString : string (virtual) -> retorna estados de la instancia

        public virtual string UtilesToString()
        {
            return this.Marca.ToString() + "--" + this.Precio.ToString();
        }

    }
}
