﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase20
{
    public class Goma : Utiles
    {
        //*-soloLapiz : bool
        protected bool _soloLapiz;

        public Goma(bool soloLapiz, string marca, double precio) : base(precio, marca)
        {
            this._soloLapiz = soloLapiz;
        }

        public override double Precio
        {
            get
            {
                return base._precio;
            }
            set
            {
                base._precio = value;
            }
        }
        public override string Marca
        {
            get
            {
                return base._marca;
            }
            set
            {
                base._marca = value;
            }
        }

        //ToString : string -> retorna estados completos de la instancia

        public override string UtilesToString()
        {
            return base.UtilesToString() + "--" + this._soloLapiz;
        }
    }
}
