﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase20
{
    public class Lapicera : Utiles
    {
        //lapicera : utiles
        //*-color : string
        //*-trazo : string
        protected string _color;
        protected string _trazo;

        public Lapicera(string color, string trazo, string marca, double precio) :base (precio, marca)
        {
            this._color = color;
            this._trazo = trazo;
        }

        public override double Precio
        {
            get
            {
                return base._precio;
            }
            set
            {
                base._precio = value;
            }
        }
        public override string Marca
        {
            get
            {
                return base._marca;
            }
            set
            {
                base._marca = value;
            }
        }

        //ToString : string -> retorna estados completos de la instancia

        public override string UtilesToString()
        {
            return base.UtilesToString() + "--" + this._color + "--" + this._trazo;
        }
    }
}
