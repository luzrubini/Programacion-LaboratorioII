﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.Externa;

namespace Clase19
{
    public class PersonaExternaHeredada : PersonaExterna
    {
        #region Constructores
        public PersonaExternaHeredada(string n, string a, int e, Entidades.Externa.ESexo s) :base (n, a, e, s)
        {
        }
        #endregion
        #region Propiedades
        protected string Nombre { get { return this._nombre; } }
        protected string Apellido { get { return this._apellido; } }
        protected int Edad { get { return this._edad; } }
        protected Entidades.Externa.ESexo Sexo { get { return this._sexo; } }
        #endregion
        #region Metodos Getters
        public string GetNombre()
        {
            return this.Nombre;
        }
        public string GetApellido()
        {
            return this.Apellido;
        }
        public string GetEdad()
        {
            return this.Edad.ToString();
        }
        public string GetSexo()
        {
            return this.Sexo.ToString();
        }
        #endregion
        #region Metodos

        public string ObtenerDatos()
        {
            return this.GetNombre() + "-" + this.GetApellido() + "-" + this.GetEdad() + "-" + this.GetSexo();
        }
        #endregion
    }
}
