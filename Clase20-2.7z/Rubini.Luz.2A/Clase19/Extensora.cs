﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Xml;
using System.Data;
using System.Xml.Serialization;
namespace Clase19
{
    //no se puede instanciar.
    //Todo debe ser estatico
    public static class Extensora 
    {
        public static string ObtenerDatos(this Entidades.Externa.Sellada.PersonaExternaSellada pe)
        {
            return pe.Nombre + "-" + pe.Apellido + "-" + pe.Edad + "-" + pe.Sexo;
        }
        public static bool EsNulo(this object obj)
        {
            bool r = true;
            if (obj != null)
            {
                r = false;
            }
            return r;
        }
        public static Int32 CantidadDigitos(this Int32 num)
        {
            string numS = "";
            Int32 cant = 0;
            numS = num.ToString();
            cant = numS.Length;
            return cant;
        }
        public static bool TieneLaMismaCantidad(this Int32 num, Int32 num2)
        {
            bool r = false;
            if (num.CantidadDigitos() == num2.CantidadDigitos())
            {
                r = true;
            }
            return r;
        }
        public static List<Persona> TraerBD(this Persona p)
        {
            SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);

            SqlCommand comando = new SqlCommand();

            comando.CommandText = "SELECT * FROM personitas";
            comando.CommandType = System.Data.CommandType.Text;
            comando.Connection = conexion;
            conexion.Open();
            SqlDataReader lector = comando.ExecuteReader();
            List<Persona> listaPersona = new List<Persona>();
            while (lector.Read())
            {
                Persona t = new Persona(lector.GetString(1), lector.GetString(2), lector.GetInt32(3), (ESexo)lector.GetInt32(4));
                listaPersona.Add(t);
            }
            conexion.Close();
            lector.Close();
            return listaPersona;
        }
        public static bool AgregarBD(this Persona p)
        {
            bool retorno = false;
            int s = -1;
            SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);
            SqlCommand comando = new SqlCommand();

            switch (p.GetSexo())
            {
                case ESexo.Femenino:
                    s = 0;
                    break;
                case ESexo.Masculino:
                    s = 1;
                    break;
                case ESexo.Indeterminado:
                    s = 2;
                    break;
                default:
                    break;
            }
            comando.CommandText = string.Format("INSERT INTO personitas values ('{0}','{1}',{2},{3})", p.GetNombre(), p.GetApellido(), p.GetEdad(),s);
            comando.CommandType = System.Data.CommandType.Text;
            comando.Connection = conexion;
            try
            {
                conexion.Open();
                comando.ExecuteNonQuery(); //ejecuta consultas que no van a retornar ningun tipo de resultado
                conexion.Close();
                retorno = true;
            }
            catch (Exception e)
            {
                throw e;
            }


            return retorno;
        }
        public static bool ModificarBD(this Persona p, int num)
        {
            bool retorno = false;
            int s = -1;
            switch (p.GetSexo())
            {
                case ESexo.Femenino:
                    s = 0;
                    break;
                case ESexo.Masculino:
                    s = 1;
                    break;
                case ESexo.Indeterminado:
                    s = 2;
                    break;
                default:
                    break;
            }
            SqlConnection connection = new SqlConnection(Properties.Settings.Default.Conexion);
            SqlCommand command = new SqlCommand();
            command.CommandText = string.Format("UPDATE personitas SET nombre = '{0}', apellido = '{1}', edad = {2}, sexo = {3} WHERE id = {4}",p.GetNombre(), p.GetApellido(), p.GetEdad(), s,num);
            command.CommandType = System.Data.CommandType.Text;
            command.Connection = connection;
            try
            {
                connection.Open();
                command.ExecuteNonQuery(); //ejecuta consultas que no van a retornar ningun tipo de resultado
                connection.Close();
                retorno = true;
            }
            catch (Exception e)
            {
                throw e;
            }

            return retorno;
        }
        public static bool BorrarBD(this Persona p, int num)
        {
            bool retorno = true;
            SqlConnection connection = new SqlConnection(Properties.Settings.Default.Conexion);
            SqlCommand command = new SqlCommand();
            command.CommandText = string.Format("DELETE personitas WHERE id = {0}", num);
            command.CommandType = System.Data.CommandType.Text;
            command.Connection = connection;
            try
            {
                connection.Open();
                command.ExecuteNonQuery(); //ejecuta consultas que no van a retornar ningun tipo de resultado
                connection.Close();
                retorno = true;
            }
            catch (Exception e)
            {
                throw e;
            }
            return retorno;
        }

    }
    
}
