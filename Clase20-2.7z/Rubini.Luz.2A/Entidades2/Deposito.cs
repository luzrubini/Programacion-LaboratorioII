﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Entidades2
{
    public class Deposito<T>
    {
        private int _capacidadMaxima;
        private List<T> _lista;
        #region Constructores
        private Deposito()
        {
            this._lista = new List<T>();
        }
        public Deposito(int capacidad) : this()
        {
            this._capacidadMaxima = capacidad;
        }
        #endregion
        #region Metodos
        private int GetIndice(T a)
        {
            int indice = -1;
            foreach (T item in this._lista)
            {
                if (a.Equals(item))
                {
                    indice = this._lista.IndexOf(item);
                    break;
                }
            }
            return indice;
        }
        public bool Agregar(T a)
        {
            return (this + a);
        }
        public bool Remover(T a)
        {
            return (this - a);
        }
        public bool Guardar(string cadena)
        {
            bool retorno = false;
            try
            {
                using (StreamWriter sw = new StreamWriter(cadena)) //true: hay arch y agrega informacion, false lo pisa.
                {
                    sw.Write(this.ToString());
                    retorno = true;
                }
            }
            catch (Exception e)
            {
                Console.Write(e.Message);
            }
            return retorno;
        }
        public bool Recuperar(string cadena)
        {
            bool retorno = false;
            try
            {
                StreamReader sr = new StreamReader(cadena);
                Console.Write(sr.ReadToEnd());
                retorno = true;
                sr.Close();
            }
            catch (Exception e)
            {
                Console.Write(e.Message);
            }
            return retorno;
        }
        #endregion
        #region Sobrecargas
        public static bool operator +(Deposito<T> d, T a)
        {
            bool retorno = false;
            if (d._lista.Count < d._capacidadMaxima)
            {
                d._lista.Add(a);
                retorno = true;

            }

            return retorno;
        }
        public static bool operator -(Deposito<T> d, T a)
        {
            bool retorno = false;
            int indice = d.GetIndice(a);
            if (indice != -1)
            {
                d._lista.RemoveAt(indice);
                retorno = true;
            }
            return retorno;
        }
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Capacidad maxima: {0}\n", this._capacidadMaxima);
            sb.AppendLine("Listado: ");
            foreach (T a in this._lista)
            {
                sb.AppendFormat("{0}\n", a.ToString());
            }
            return sb.ToString();
        }
        #endregion
    }
}
