﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades2
{
    public class DepositoDeAutos
    {
        private int _capacidadMaxima;
        private List<Auto> _lista;
        #region Constructores
        private DepositoDeAutos()
        {
            this._lista = new List<Auto>();
        }
        public DepositoDeAutos(int capacidad) :this()
        {
            this._capacidadMaxima = capacidad;
        }
        #endregion
        #region Metodos
        private int GetIndice(Auto a)
        {
            int indice = -1;
            foreach (Auto item in this._lista)
            {
                if (a == item)
                {
                    indice = this._lista.IndexOf(item);
                    break;
                }
            }
            return indice;
        }
        public bool Agregar(Auto a)
        {
            return (this + a);
        }
        public bool Remover(Auto a)
        {
            return  (this - a);
        }
        #endregion
        #region Sobrecargas
        public static bool operator +(DepositoDeAutos d, Auto a)
        {
            bool retorno = false;
            if (d._lista.Count < d._capacidadMaxima)
            {
                d._lista.Add(a);
                retorno = true;

            }

            return retorno;
        }
        public static bool operator -(DepositoDeAutos d, Auto a)
        {
            bool retorno = false;
            int indice = d.GetIndice(a);
            if (indice != -1)
            {
                d._lista.RemoveAt(indice);
                retorno = true;
            }
            return retorno;
        }
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Capacidad maxima: {0}\n", this._capacidadMaxima);
            sb.AppendLine("Listado de autos: ");
            foreach (Auto a in this._lista)
            {
                sb.AppendFormat("{0}\n", a.ToString());
            }
            return sb.ToString();
        }
        #endregion
    }
}
