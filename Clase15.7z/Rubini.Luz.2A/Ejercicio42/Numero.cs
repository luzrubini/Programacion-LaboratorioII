﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio42
{
    public class Numero
    {
        public double dividir;
        public Numero(int x, int y)
        {
            try
            {
                dividir = Dividir(x, y);
            }
            catch (DivideByZeroException e)
            {
                throw new UnaExcepcion(e.Message + "Una excepcion", e);
            }
        }
        public static double Dividir (int x, int y)
        {
           double retorno = 0;
            if (y != 0)
            {
                retorno = x / y;
            }
            else
            {
                throw new DivideByZeroException("Divido por 0");
            }
            return retorno;
        }
    }
}
