﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase04Entidades
{
    class Cosa
    {
        #region Atributos
        public string cadena;
        public double numero;
        public DateTime fecha;
        #endregion
        #region Constructores
        public Cosa()
        {
            this.cadena = "Sin valor";
            this.numero = 1.9;
            this.fecha = DateTime.Now;
        }
        public Cosa(string cadenaR):this()
        {
            this.cadena = cadenaR;
        }
        #endregion
        #region Métodos
        public static string Mostrar(Cosa cosaA)
        {
            return cosaA.Mostrar();
        }
        private string Mostrar ()
        {
            return this. cadena + "--" + this.numero.ToString() + "--" + this.fecha.ToLongDateString();
        }
        public void EstablecerValor(string cadena)
        {
            this.cadena = cadena;
        }
        public void EstablecerValor(DateTime fecha)
        {
            this.fecha = fecha;
        }
        public void EstablecerValor(double numero)
        {
            this.numero = numero;
        }
        #endregion
    }
}
