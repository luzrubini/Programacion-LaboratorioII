﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase07Entidades
{
    public class PaletaColeccion
    {
        private List<Tempera> _colores;
        private int _cantMaximaElementos;
        
        #region Constructores
        private PaletaColeccion() : this(5)
        {

        }
        private PaletaColeccion(int cantidad)
        {
            this._cantMaximaElementos = cantidad;
            this._colores = new List<Tempera>();
        }
        #endregion
        #region Metodos
        private string Mostrar()
        {

            ; string retorno = "";
            foreach (Tempera unaTempera in this._colores)
            {
                if (!(Object.Equals(unaTempera, null)))
                {
                    retorno += unaTempera;
                    retorno += "\r\n";
                }
            }
            return retorno;
        }
        public static explicit operator string(PaletaColeccion paleta)
        {
            return paleta.Mostrar();
        }
        public static implicit operator PaletaColeccion(int cantidad)
        {

            return new PaletaColeccion(cantidad);
        }
        
        #endregion
        #region Sobrecargas
        public static bool operator ==(PaletaColeccion paleta, Tempera tempera)
        {
            bool retorno = false;

            foreach (Tempera item in paleta._colores)
            {
                if(item == tempera)
                {
                    retorno = true;
                    break;
                }
            }
            return retorno;
        }
        public static bool operator !=(PaletaColeccion paleta, Tempera tempera)
        {
            return !(paleta == tempera);
        }
        public static PaletaColeccion operator +(PaletaColeccion paleta, Tempera tempera)
        {
            Tempera auxTempera = null;
            bool flag = false;
            int indice = -1;
            foreach (Tempera item in paleta._colores)
            {
                if (item == tempera)
                {
                    
                    indice = paleta._colores.IndexOf(item);
                    flag = true;
                    break;
                }
            }
            if(flag == true)
            {
                auxTempera = paleta._colores.ElementAt(indice);
                auxTempera += tempera;
                paleta._colores.Insert(indice,auxTempera);

            }
           else if (paleta._cantMaximaElementos > paleta._colores.Count)
            {
                paleta._colores.Add(tempera);
            }
            return paleta;
        }
        //Clase 08
        public static PaletaColeccion operator -(PaletaColeccion paleta, Tempera tempera)
        {
            Tempera auxTempera = null;
            int aux1 = 0, aux2 = 0, indice = -1;
            foreach(Tempera item in paleta._colores)
            {
                if(item == tempera)
                {
                    auxTempera = item;
                    indice = paleta._colores.IndexOf(auxTempera);
                    break;
                }
            }
            aux1 = (sbyte)auxTempera;
            aux2 = (sbyte)tempera;
            if (aux1 - aux2 <= 0)
            {
                paleta._colores.Remove(auxTempera);
            }
            else
            {
                auxTempera += (sbyte)(aux2 * (-1));
                paleta._colores.Insert(indice, auxTempera);
            }

            return paleta;
        }
        #endregion
    }
}
