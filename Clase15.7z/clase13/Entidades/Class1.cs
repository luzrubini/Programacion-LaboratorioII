﻿using System;

namespace Entidades
{
    public class Class1
    {
    }
}
